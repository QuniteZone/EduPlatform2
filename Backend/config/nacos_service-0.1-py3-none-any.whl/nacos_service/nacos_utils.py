# -*- coding: utf-8 -*-
import os
import yaml
import time
import nacos
import random
import socket
import logging
import requests
from nacos.timer import NacosTimer


def localhost_ip():
    """获取服务所在机器的ip地址

    Returns:
        服务所在机器的ip地址
    """
    ip = "127.0.0.1"
    s = None
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    finally:
        s.close()
    return ip


def dict2obj(d):
    """
    将字典转换成对象
    """
    top = type('dict', (object,), d)
    seqs = tuple, list, set, frozenset
    for i, j in d.items():
        if isinstance(j, dict):
            setattr(top, i, dict2obj(j))
        elif isinstance(j, seqs):
            setattr(top, i,
                    type(j)(dict2obj(sj) if isinstance(sj, dict) else sj for sj in j))
        else:
            setattr(top, i, j)
    return top


class ServiceConfig(object):
    __FILE__ = 'resources' + os.path.sep + 'service.template'
    _instance = None
    _is_init = False
    # 重启客户端时间间隔 (s)
    _restart_interval = [5, 10, 30, 60, 60 * 10, 60 * 30, 60 * 60]
    _restart_count = 0

    def __new__(cls, *args, **kw):
        if cls._instance is None:
            cls._instance = object.__new__(cls)
        return cls._instance

    def __init__(self, config_fp):
        """构造函数，初始化nacos配置信息

        Args:
            config_fp: 服务配置路径，为None时读取默认配置文件
        """
        if not ServiceConfig._is_init:
            config_fp = os.path.join(os.path.dirname(os.path.dirname(os.path.realpath(__file__))),
                                     ServiceConfig.__FILE__) \
                if config_fp is None else config_fp
            # 加载服务列表
            with open(config_fp, 'r', encoding="utf-8") as f:
                config_str = f.read()
            service_cfg = dict2obj(yaml.load(config_str, Loader=yaml.FullLoader))
            """
            配置如下环境变量覆盖默认配置：
            ENABLE_NACOS
            NACOS_SERVER
            NACOS_PORT
            NACOS_GROUP
            NACOS_HEARTBEAT_INTERVAL
            NACOS_PREFIX
            """
            if os.getenv('ENABLE_NACOS') is None:
                self.enable_nacos = service_cfg.nacos.enable
            else:
                self.enable_nacos = True if os.getenv('ENABLE_NACOS') == "true" else False
            self.address = 'http://{}:{}'.format(os.getenv('NACOS_SERVER') or service_cfg.nacos.ip,
                                                 os.getenv('NACOS_PORT') or service_cfg.nacos.port)

            self.namespace = service_cfg.nacos.namespace  # public
            self.group = os.getenv('NACOS_GROUP') or nacos.client.DEFAULT_GROUP_NAME
            # self.service_data_id = service_cfg.nacos.service_data_id
            self.heartbeat_interval = int(os.getenv('NACOS_HEARTBEAT_INTERVAL') or service_cfg.nacos.heartbeat_interval)
            self.prefix = os.getenv('NACOS_PREFIX') or getattr(service_cfg.nacos, 'prefix', 'ai-studio')
            self.current_service = service_cfg.nacos.current_service.strip()
            self.current_service_port = getattr(service_cfg.services, self.current_service).port
            self.services = service_cfg.services

            if self.enable_nacos:
                self.connect()
                # def svc_cfg_watcher(args):
                #     print('配置改变')
                #     self.services = dict2obj(yaml.load(args["content"]))
                # self.client.add_config_watcher(self.service_data_id, self.group, svc_cfg_watcher)
            else:
                self.client = None
                self.services = service_cfg.services
            # 初始化完成
            ServiceConfig._is_init = True

    def init_app(self, app):
        app.config['SERVICE_CONFIG'] = self
        assert self is not None

    def connect(self, restart_time=-1):
        """
        启动Nacos时有效，用于重启客户端

        Args:
            restart_time： 连接失败时的重启次数， -1：无限重启
        """
        try:
            nacos.client.logger.setLevel(logging.WARNING)
            self.client = nacos.NacosClient(self.address, namespace=self.namespace)
            self.client.add_naming_instance(self.instance_name, self.service_ip,
                                            self.current_service_port, "DEFAULT", 0.1, "{}",
                                            True, True, True, group_name=self.group)
            self.heartbeat_timer = NacosTimer("heartbeat_timer", self.send_heartbeat,
                                              self.heartbeat_interval,
                                              self.instance_name, self.service_ip,
                                              self.current_service_port)
            self.heartbeat_timer.scheduler()
        except Exception as e:
            if restart_time == -1 or self._restart_count <= restart_time:
                wait_time = self._restart_interval[self._restart_count % len(self._restart_interval)]
                time.sleep(wait_time)
                self._restart_count += 1
                self.connect()
            else:
                raise Exception("连接服务失败：{}".format(str(e)))

    def send_heartbeat(self, service_name, ip, port):
        """nacos服务心跳检测

        Args:
            service_name: 注册在nacos中的服务名
            ip: 服务ip
            port: 服务端口
        """
        try:
            self._instance.client.send_heartbeat(service_name, ip, port, group_name=self.group)
        except:
            self.connect()

    def instance_name_of_service(self, svc_name):
        return "-".join([self.prefix, svc_name]) if self.prefix else svc_name

    @property
    def instance_name(self):
        return self.instance_name_of_service(self.current_service)

    @property
    def service_ip(self):
        return localhost_ip()
        # return "{}-service".format(self.instance_name)

    def get_instance(self, instance_name) -> dict:
        """
        获取实例信息
        """
        try:
            instance_info = self.client.list_naming_instance(instance_name)
        except Exception as ex:
            raise Exception('获取服务信息失败：{}'.format(str(ex)))
        return instance_info

    def svc_address_by_name(self, service_name) -> str:
        """
        根据服务名获取服务地址
        """
        service_name = service_name.strip()
        if self.enable_nacos:
            # inst_name = self.instance_name_of_service(service_name) \
            #     if getattr(self.services, service_name, False) else service_name
            # instance_info = self.get_instance(inst_name)
            inst_name = service_name
            instance_info = self.get_instance(inst_name)
            if len(instance_info['hosts']) == 0:
                raise Exception('服务 {} 不存在'.format(service_name))
            svc_index = random.randint(0, len(instance_info['hosts']) - 1)
            ip = instance_info['hosts'][svc_index]['ip']
            port = instance_info['hosts'][svc_index]['port']
        else:
            service = getattr(self.services, service_name, None)
            if service is None:
                raise Exception('服务 {} 不存在'.format(service_name))
            ip = service.ip
            port = service.port
        return 'http://{ip}:{port}'.format(ip=ip, port=port)

    def fget(self, service_name, get_url, **kwargs):
        url = self.svc_address_by_name(service_name) + get_url
        try:
            return requests.get(url, timeout=30, **kwargs)
        except Exception as e:
            print(e)

    def fpost(self, service_name, post_url, **kwargs):
        url = self.svc_address_by_name(service_name) + post_url
        try:
            return requests.post(url, timeout=30, **kwargs)
        except Exception as e:
            print(e)

